-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 14, 2021 at 04:24 PM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `invertory`
--

-- --------------------------------------------------------

--
-- Table structure for table `empolyee`
--

DROP TABLE IF EXISTS `empolyee`;
CREATE TABLE IF NOT EXISTS `empolyee` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_name` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `emp_fname` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `emp_surename` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `emp_jop` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `empolyee`
--

INSERT INTO `empolyee` (`emp_id`, `emp_name`, `emp_fname`, `emp_surename`, `emp_jop`) VALUES
(1, 'Rohullah', 'M,jawad', 'Hassani', 'En'),
(2, 'Sharif', 'M,Salaim', 'Juhoon', 'Teacher'),
(7, 'hamid', 'jawad', '\r\n        hassani', 'dr');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE IF NOT EXISTS `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `item_price` int(11) NOT NULL,
  `item_data` varchar(15) COLLATE utf8_persian_ci NOT NULL,
  `item_emp_id` int(11) NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item_name`, `item_price`, `item_data`, `item_emp_id`) VALUES
(1, 'my Computer', 12000, '2021-01-05', 1),
(2, 'pencel', 2, '2021-01-19', 2),
(4, 'tablet', 40000, '2021-01-10', 1),
(5, 'Computer', 43455, '2021-01-11', 1),
(7, 'tablet', 12000, '2021-01-05', 1),
(8, 'phone', 1222, '2021-Jan-Mon', 1),
(9, 'book', 40, '', 2),
(10, 'book', 40, '2021-Jan-Mon', 2),
(11, 'pen1', 2, '2021-Jan-Mon', 2),
(12, 'desk', 100, '2021-Jan-Mon', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
