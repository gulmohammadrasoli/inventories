  <?php
      include("inculde/connection.php");
      include("inculde/header.php");

      if(isset($_POST['btn_insert'])){
        $i_name=$_POST['item_name'];
        $i_price=$_POST['item_price'];
        $i_date=$_POST['item_date'];
        $i_item_emp=$_POST['item_emp'];

        $query_item="INSERT INTO items (item_name,item_price,item_data,item_emp_id)VALUES('$i_name','$i_price','$i_date','$i_item_emp');";
        mysqli_query($con,$query_item);
         if(!mysqli_query($con,$query_item)){
          header("location:add_item.php");
         }
        
      }
      else{
        $query_emp="SELECT emp_id,emp_name FROM empolyee";
        mysqli_set_charset($con,"utf8");
        $result_emp=mysqli_query($con,$query_emp);
      }

  ?>
    
    <div class="container-fluid">
      <div class="row" id="top">  
        <div class="col-md-3">
          <img src="picture/logo/logo.png" class="img-responsive" id="logo">
        </div>
        <div class="col-md-6"></div>
        <div class="col-md-3">
          <h1 id="title"> خدمات نرم افزاری  </h1>
        </div>
      </div>

      <div class="row">
        <div class="col-md-8 col-md-offset-2" dir="rtl">
          <h1 id="title">اضافه نمودن اجناس جدید</h1>
          <br />
          <form class="form-horizontal" action="" method="post">

            <div class="form-group">
              <div class="col-sm-10">
                <input type="text " class="form-control" name="item_name" required>
                </div>
                <label class="col-sm-2 control-label">نام جنس</label>
              </div>

              <div class="form-group">
              <div class="col-sm-10">
                <input type="text" class="form-control" name="item_price" required>
                </div>
                <label class="col-sm-2 control-label">قیمت <label>
              </div>

              <div class="form-group">
              <div class="col-sm-10">
                <input type="text" class="form-control" name="item_date"value="<?php echo date('Y-M-D') ?>">
                </div>
                <label class="col-sm-2 control-label"> تاریخ <label>
              </div>

              <div class="form-group">
              <div class="col-sm-10">
                <select class="form-control" name="item_emp">
                  <?php
                  $row=mysqli_fetch_assoc($result_emp);
                  if($row){
                    do{
                      echo "<option value='".$row['emp_id']."'>".$row['emp_name']."</option>";
                    }
                    while($row=mysqli_fetch_assoc($result_emp));
                  }


                  ?>
                </select>
              </div>
                <label class="col-sm-2 control-label"> کارمند  </label>
              </div>

              <div class="form-group">
                <div class="row">
                  <div class="col-md-2 col-md-offset-0.5">
                    <input type="submit" name="btn_insert" class="btn btn-success btn-block"  value=" افزودن ">
                  </div>
                  <div class="col-md-6">
                  </div>
                  <div class="col-md-2">
                    <a href="index.php" class="btn btn-success btn-block"> برگشت </a>
                  </div>
                </div>
              </div>
          </form>
        </div>
      </div>
    </div>

    <?php
      include("inculde/footer.php");
  ?>
