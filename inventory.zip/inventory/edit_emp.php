<?php
    include("inculde/connection.php");
    include("inculde/header.php");

    $newid;

   
    ?>

    <div class="container-fluid">
        <div class="row" id="top">
            <div class="col-md-3">
                <img src="picture/logo/logo.png" class="img-responsive" id="logo">
            </div>
            <div class="col-md-6"></div>
            <div class="col-md-3">
                <h1 id="title"> خدمات نرم افزاری  </h1>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8 col-md-offset-2" dir="rtl">
                <h1 id="title">اضافه نمودن اجناس جدید</h1>
                <br />
              <?php
                if(isset($_GET['id'])){
                    $newid=$_GET['id'];
                    $query="SELECT * FROM items where item_id = $newid";
                    mysqli_set_charset($con,"utf8");
                    $result = mysqli_query($con,$query);
                    $arr=mysqli_fetch_assoc($result);
                    do {

                        ?>
                        <form class="form-horizontal" action="" method="post">

                        <div class="form-group">
                            <div class="col-sm-10">
                                <input type="text " class="form-control" name="item_name"
                                       value="<?php echo $arr['item_name']; ?>">
                            </div>
                            <label class="col-sm-2 control-label">نام جنس</label>
                        </div>

                        <div class="form-group">
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="item_price"
                                   value="<?php echo $arr['item_price'];?>" >
                        </div>
                        <label class=" col-sm-2 control-label">قیمت <label>
                        </div>

                        <div class="form-group">
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="item_date"
                                       value="<?php echo $arr['item_data']; ?>">
                            </div>
                            <label class="col-sm-2 control-label"> تاریخ <label>
                        </div>

                        <?php
                    }
                while($arr=mysqli_fetch_assoc($result));
                }
                ?>

                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-2 col-md-offset-0.5">
                                <input type="submit" name="btn_insert" class="btn btn-success btn-block"  value=" ویرایش ">
                            </div>
                            <div class="col-md-6">
                            </div>
                            <div class="col-md-2">
                                <a href="index.php" class="btn btn-success btn-block"> برگشت </a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php
     if(isset($_POST['btn_insert'])){
    $i_name=$_POST['item_name'];
    $i_price=$_POST['item_price'];
    $i_date=$_POST['item_date'];
    $query="UPDATE items SET item_name ='$i_name',item_price='$i_price',item_data='$i_date' WHERE item_id =$newid";

    $result2 =mysqli_query($con,$query);
    if($result2){
        header('location:index.php');
    }
    else{

        echo "<div class='alert alert-danger'>try agine</div>";
    }
    }

    include("inculde/footer.php");
?>