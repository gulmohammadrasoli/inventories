  <script src="style/js/jquery.min.js"></script>
    <script src="style/js/bootstrap.min.js"></script>
  </body>
</html>

