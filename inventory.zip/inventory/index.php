  <?php
      include("inculde/connection.php");
      include("inculde/header.php");

        if(isset($_POST['serach'])){
          $serach=$_POST['serach'];
          $query="SELECT * FROM items,empolyee where items.item_emp_id=empolyee.emp_id and concat(item_id,item_name,item_price,item_data,emp_name) like '%$serach%'";
           mysqli_set_charset($con,"utf8");
           $result=mysqli_query($con,$query);
         }
         else{
          $query="SELECT item_id,item_name,item_price,item_data,emp_name FROM items,empolyee where items.item_emp_id=empolyee.emp_id";
          mysqli_set_charset($con,"utf8");
          $result=mysqli_query($con,$query);
         }
  ?>




    <div class="container-fluid">
      <div class="row" id="top">  
        <div class="col-md-3">
          <img src="picture/logo/logo.png" class="img-responsive" id="logo">
        </div>
        <div class="col-md-6"></div>
        <div class="col-md-3">
          <h1 id="title"> خدمات نرم افزاری  </h1>
        </div>
      </div>


      <div class="row">
        <div class="col-md-4" id="menu">
          <ul class="nav nav-pills">
            <li role="presentation"><a href="add_emp.php">کارمند جدید </a></li>
            <li role="presentation"><a href="add_item.php">جنس جدید</a></li>
            <li role="presentation"><a href="emp_list.php">لیست کارمندان</a></li>
            <li role="presentation" class="active"><a href="index.php">صفحه اصلی</a></li>
          </ul>
        </div>
        <div class="col-md-6" id="serach">
          <form class="form-inline" method="post" action="">
            <div class="form-group">
              <div class="input-group">
                <input type="text" class="form-control"name="serach" placeholder="جستجو  ">
                <div class="input-group-addon"><a href="index.php" class="glyphicon glyphicon-refresh"></a></div>
              </div>
              <input type="submit" value="جستجو" class="btn btn-success">
            </div>
          </form>
        </div>
        <div class="col-md-2">
          <h3> لیست اجناس  </h3>
        </div>
      </div>
      <br />

      <div class="row">
        <div class="col-md-12">

          <table class="table table-striped" dir="rtl">
            <thead>
              <tr class="danger">
                <th>نام جنس </th>
                <th>قیمت</th>
                <th>تاریخ</th>
                <th>کارمند</th>
                <th>عملیات</th>
                <th>عملیات</th>
              </tr>
            </thead>

            <tbody>
              <?php
              $row=mysqli_fetch_assoc($result);
              if($row){
                do{
                echo "<tr>";
                echo "<td>".$row['item_name']."</td>";
                echo "<td>".$row['item_price']."</td>";
                echo "<td>".$row['item_data']."</td>";
                echo "<td>".$row['emp_name']."</td>";
                echo "<td><a href='edit_emp.php?id=".$row['item_id']."'><span class='glyphicon glyphicon-edit'></span></a></td>";
                echo "<td><a href='delete?id=".$row['item_id']."'><span class='glyphicon glyphicon-remove'></span></a></td>";
                echo "</tr>";
                }
                while($row=mysqli_fetch_assoc($result));
              }


              ?>
            </tbody>

          </table>

        </div>
      </div>
    </div>
    <?php
      include("inculde/footer.php");
  ?>
